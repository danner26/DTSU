public class Tester
{
    private String password;
    
    public Tester()
    {
        password = "";
    }
    public Tester(String pass)
    {
        password = pass;
    }
    
    public void setPassword(String pass)
    {
        password = pass;
    }
    public String getPassword()
    {
        return password;
    }
    
    public boolean empty()
    {
        return password.isEmpty();
    }
    public int indexOfSpace()
    {
        return password.indexOf(" ");
    }
    public static int lengthOfPassword(String password)
    {
        return password.length();
    }
    public boolean containsKnownWord()
    {
        String[] knownWords = { "password", "12345678", "123456789", "iloveyou", "adobe123", "1234567890", "letmein","photoshop", "sunshine", "password1", "princess", "trustno1"}; 
        if (password.equalsIgnoreCase(knownWords[0]))
             return true;
        else if (password.equalsIgnoreCase(knownWords[1]))
             return true;
        else if (password.equalsIgnoreCase(knownWords[2]))
             return true;
        else if (password.equalsIgnoreCase(knownWords[3]))
             return true;
        else if (password.equalsIgnoreCase(knownWords[4]))
             return true;
        else if (password.equalsIgnoreCase(knownWords[5]))
             return true;
        else if (password.equalsIgnoreCase(knownWords[6]))
             return true;
        else if (password.equalsIgnoreCase(knownWords[7]))
             return true;
        else if (password.equalsIgnoreCase(knownWords[8]))
             return true;
        else if (password.equalsIgnoreCase(knownWords[9]))
             return true;
        else if (password.equalsIgnoreCase(knownWords[10]))
             return true;
        else if (password.equalsIgnoreCase(knownWords[11]))
             return true;
        else
             return false;
    }
    public boolean containsNum()
    {
        CharSequence[] num = {"1", "2", "3", "4", "5", "6", "7", "8", "9"};
        if (password.contains(num[0]))
             return true;
        else if (password.contains(num[1]))
             return true;
        else if (password.contains(num[2]))
             return true;
        else if (password.contains(num[3]))
             return true;
        else if (password.contains(num[4]))
             return true;
        else if (password.contains(num[5]))
             return true;
        else if (password.contains(num[6]))
             return true;
        else if (password.contains(num[7]))
             return true;
        else if (password.contains(num[8]))
             return true;
        else
             return false;
    }
    public boolean containsCap()
    {
        CharSequence[] caps = {"A", "B", "C", "D", "E", "F", "G", "H", "I", "J", "K", "L", "M", "N", "O", "P", "Q", "R", "S", "T", "U", "V", "W", "X", "Y", "Z"};
        if (password.contains(caps[0]))
             return true;
        else if (password.contains(caps[1]))
             return true;
        else if (password.contains(caps[2]))
             return true;
        else if (password.contains(caps[3]))
             return true;
        else if (password.contains(caps[4]))
             return true;
        else if (password.contains(caps[5]))
             return true;
        else if (password.contains(caps[6]))
             return true;
        else if (password.contains(caps[7]))
             return true;
        else if (password.contains(caps[8]))
             return true;
        else if (password.contains(caps[9]))
             return true;
        else if (password.contains(caps[10]))
             return true;
        else if (password.contains(caps[11]))
             return true;
        else if (password.contains(caps[12]))
             return true;
        else if (password.contains(caps[13]))
             return true;
        else if (password.contains(caps[14]))
             return true;
        else if (password.contains(caps[15]))
             return true;
        else if (password.contains(caps[16]))
             return true;
        else if (password.contains(caps[17]))
             return true;
        else if (password.contains(caps[18]))
             return true;
        else if (password.contains(caps[19]))
             return true;
        else if (password.contains(caps[20]))
             return true;
        else if (password.contains(caps[21]))
             return true;
        else if (password.contains(caps[22]))
             return true;
        else if (password.contains(caps[23]))
             return true;
        else if (password.contains(caps[24]))
             return true;
        else if (password.contains(caps[25]))
             return true;
        else
             return false;
    }
    public boolean containsPunc()
    {
        CharSequence[] punc = {"!", "@", "#", "$", "%", "^", "&", "*", "(", ")", ",", ".", "/", ":", ";", "'", "[", "]", "{", "}", "-", "=", "+", "_", "|"};
        if (password.contains(punc[0]))
             return true;
        else if (password.contains(punc[1]))
             return true;
        else if (password.contains(punc[2]))
             return true;
        else if (password.contains(punc[3]))
             return true;
        else if (password.contains(punc[4]))
             return true;
        else if (password.contains(punc[5]))
             return true;
        else if (password.contains(punc[6]))
             return true;
        else if (password.contains(punc[7]))
             return true;
        else if (password.contains(punc[8]))
             return true;
        else if (password.contains(punc[9]))
             return true;
        else if (password.contains(punc[10]))
             return true;
        else if (password.contains(punc[11]))
             return true;
        else if (password.contains(punc[12]))
            return true;
        else if (password.contains(punc[13]))
             return true;
        else if (password.contains(punc[14]))
             return true;
        else if (password.contains(punc[15]))
             return true;
        else if (password.contains(punc[16]))
             return true;
        else if (password.contains(punc[17]))
             return true;
        else if (password.contains(punc[18]))
             return true;
        else if (password.contains(punc[19]))
             return true;
        else if (password.contains(punc[20]))
             return true;
        else if (password.contains(punc[21]))
             return true;
        else if (password.contains(punc[22]))
             return true;
        else if (password.contains(punc[23]))
             return true;
        else if (password.contains(punc[24]))
             return true;
        else
             return false;
    }
    //public boolean testConsecCaps()
    //{
    //    boolean consec = Consec.containConsecCaps(password);
    //    return consec;
    //}
    
}